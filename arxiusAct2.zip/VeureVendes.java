import org.neodatis.odb.ODB;
import org.neodatis.odb.ODBFactory;
import org.neodatis.odb.Objects;

import ElsMeusBeans.Venda;

public class VeureVendes {
    public static void main (String[] args) {
        //Obrir la base de dades
        ODB odb = ODBFactory.open("Producte_com.BD");
        //Es recuperen tots els objectes
        Objects<Venda> objects = odb.getObjects(Venda.class);
        System.out.println(objects.size()+" Vendes: ");
        
        int i = 1;
        //Mostra els productes
        while (objects.hasNext()) {
            Venda pro = objects.next();
            System.out.println((i++)+"\t: *ID PRODUCTE:"+pro.getIdproducte()+" *NUM VENDA:"+pro.getNumvenda()+"*QUANTITAT:"+pro.getQuantitat());
        }
        //Es tanca la base de dades
        odb.close();
    }
    
}
