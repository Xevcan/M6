import org.neodatis.odb.ODB;
import org.neodatis.odb.ODBFactory;
import org.neodatis.odb.Objects;

import ElsMeusBeans.Comanda;

public class VeureComande {
    public static void main (String[] args) {
        //Obrir la base de dades
        ODB odb = ODBFactory.open("Producte_com.BD");
        //Es recuperen tots els objectes
        Objects<Comanda> objects = odb.getObjects(Comanda.class);
        System.out.println(objects.size()+" Comanda: ");
        
        int i = 1;
        //Mostra els productes
        while (objects.hasNext()) {
            Comanda pro = objects.next();
            System.out.println((i++)+"\t: "+pro.getNumcomanda()+"*ID PRODUCTO:"+pro.getIdproducte()+" *QUANTITAT:"+pro.getQuantitat());
        }
        //Es tanca la base de dades
        odb.close();
    }
    
}